import tkinter as tk
from tkinter import *

#MAIN WINDOW AND COMPONENTS
win = tk.Tk()
win.title("Foodio!")
win.geometry("600x550")
win.configure(bg="#164A41")

# variables and lists
counter = 0
counter2 = 0
counter3 = 0
counter4 = 0
counter5 = 0
counter6 = 0
totalWaste = 0

username = ["", ""]
password = ["", ""]
foodbought = []
foodnames = []
foodLabel = []
wasteLabel = []
massBought = []
gramsWasted = []
habits = []
habitLabel = []
habitTimes = []



# universal functions
def to_main():
    mainFrame.pack(fill='both', expand=1)

    wasteFrame.forget()
    loginframe.forget()
    trackerFrame.forget()
    habitFrame.forget()
    # adminframe.forget()


def to_tracker():
    trackerFrame.pack(fill='both', expand=1)

    mainFrame.forget()
    loginframe.forget()
    wasteFrame.forget()
    habitFrame.forget()
    #frame.forget()


def to_waste():
    wasteFrame.pack(fill='both', expand=1)

    mainFrame.forget()
    loginframe.forget()
    trackerFrame.forget()
    habitFrame.forget()

def to_habits():
    habitFrame.pack(fill='both', expand=1)

    wasteFrame.forget()
    mainFrame.forget()
    loginframe.forget()
    trackerFrame.forget()

def logout():
    loginframe.pack(pady=50)
    loginBtn.configure(state=DISABLED)

    passwrdBtn.configure(state=DISABLED)
    habitFrame.forget()
    mainFrame.forget()
    trackerFrame.forget()
    wasteFrame.forget()
    usernameEnt.delete(0, END)


#LOGIN FRAME AND ITS COMPONENTS
loginframe = tk.Frame(win, width=400, height=300, bg="#12664E", padx=15, pady=15)
loginframe.pack_propagate(0)
loginframe.pack()

greeting = tk.Label(loginframe, text="", bg="#9DC88D")
loginlbl = tk.Label(loginframe, text="Welcome to Foodio!\n Make a name and password to start!", font=("Arial", 10), bg="#9DC88D")
loginlbl.grid(column=0, row=0, columnspan=3)


# login specific functions

def enteruser():
    global username
    global admnuser
    global counter2
    global greeting

    username[1] = usernameEnt.get()

    if counter == 0:
        username[0] = usernameEnt.get()
        userName = "Username logged!"
        adm1 = False
        greeting.configure(text=userName, bg="#9DC88D", font=("Arial", 10))
        greeting.grid(column=0, row=2)
        passwrdBtn.configure(state=NORMAL)
        counter2 += 1
    else:
        if username[1] == username[0]:
            greeting.configure(text=" Username Correct!", bg="#9DC88D", font=("Arial", 10))
            greeting.grid(column=0, row=2)
            passwrdBtn.configure(state=NORMAL)
            usernameEnt.delete(0, END)
            counter2 += 1

        else:
            greeting.configure(text="Incorrect Username.", bg="#9DC88D", font=("Arial", 10))
            passwrdBtn.configure(state=DISABLED)
            greeting.grid(column=0, row=2)
            usernameEnt.delete(0, END)
            counter2 += 1


def enterpass():
    global password
    global counter

    password[1] = passwrdEnt.get()

    if counter == 0:
        adm2 = False

        password[0] = passwrdEnt.get()

        greeting = tk.Label(loginframe, text="Password logged!", bg="#9DC88D", font=("Arial", 10))
        greeting.grid(column=0, row=4)
        loginBtn.configure(state=NORMAL)
        counter += 1

        passwrdEnt.delete(0, END)

    elif counter > 0:
        adm2 = False

        if password[1] == password[0]:
            greeting = tk.Label(loginframe, text=" Password Correct!", bg="#9DC88D", font=("Arial", 10))
            greeting.grid(column=0, row=4)
            loginBtn.configure(state=NORMAL)
            passwrdEnt.delete(0, END)
            counter += 1
        else:

            greeting = tk.Label(loginframe, text="Incorrect Password.", bg="#9DC88D", font=("Arial", 10))
            greeting.grid(column=0, row=4)
            loginBtn.configure(state=DISABLED)
            passwrdEnt.delete(0, END)
            counter += 1


# username set up
usernamelbl = tk.Label(loginframe, text="Username:", bg="#9DC88D", font=("Arial", 10))
usernamelbl.grid(column=0, row=1)

usernameEnt = tk.Entry(loginframe, width=25, state=NORMAL, font=("Arial", 10))
usernameEnt.grid(column=1, row=1)

usernameBtn = tk.Button(loginframe, text="ENTER", command=enteruser, bg="#F1B24A", font=("Arial", 10))
usernameBtn.grid(column=2, row=1)

# password set up
passwrdlbl = tk.Label(loginframe, text="Password:", bg="#9DC88D", font=("Arial", 10))
passwrdlbl.grid(column=0, row=3)

passwrdEnt = tk.Entry(loginframe, width=25, font=("Arial", 10))
passwrdEnt.grid(column=1, row=3)

passwrdBtn = tk.Button(loginframe, text="ENTER", command=enterpass, state=DISABLED, bg="#F1B24A", font=("Arial", 10))
passwrdBtn.grid(column=2, row=3)

loginBtn = tk.Button(loginframe, text="LOGIN", font=("Arial", 10), state=DISABLED, command=to_main, bg="#F1B24A")
loginBtn.grid(column=1, row=5, columnspan=2)


# MAINFRAME AND ALL ITS COMPONENTS

mainFrame = tk.Frame(win, width=400, height=550, bg="#164A41", padx=15, pady=15)
mainLabel = tk.Label(mainFrame,text="Click on a button to get started. \nYou can track the food you bought,\n how much you bought, and the amount of food wasted.\nYou can also track any other habits you have too!",font=("Arial", 11), bg="#9DC88D")
mainLabel.grid(column=00, row=1, columnspan=3, padx=40)

#buttons
logout = tk.Button(mainFrame, text="LOGOUT", command=logout, bg="#F1B24A", fg="#031B13", font=("Arial", 10))
logout.grid(column=0, row=0, pady=15)

foodTrackerBtn = tk.Button(mainFrame, text="FOOD TRACKER", command=to_tracker, font=("Arial", 10), bg="#F1B24A")
foodTrackerBtn.grid(column=0, row=2, pady=10)

foodWasteBtn = tk.Button(mainFrame, text="WASTE TRACKER", command=to_waste, font=("Arial", 10), bg="#F1B24A")
foodWasteBtn.grid(column=1, row=2, pady=10)

habitMainBtn = tk.Button(mainFrame, text="HABIT TRACKER", command=to_habits, bg="#F1B24A", fg="#031B13",font=("Arial", 10))
habitMainBtn.grid(column=2, row = 2)


# FOOD TRACKER AND ALL ITS COMPONENETS

#frames
trackerFrame = tk.Frame(win, width=600, height=550, bg="#164A41", padx=15, pady=15)

foodFrame = tk.Frame(trackerFrame, width=550, height=340, bg="white", padx=10, pady=10)
foodFrame.grid_propagate(0)
foodFrame.grid(row=2, column=0, columnspan=3, pady=5)

enterFrame = tk.Frame(trackerFrame, width=550, height=100, bg="white", padx=5, pady=10)
enterFrame.grid_propagate(0)
enterFrame.grid(row=3, column=0, columnspan=3, pady=10)

trackerLabel = tk.Label(trackerFrame, text="This is the food tracker frame\n you currently have nothing tracked",font=("Arial", 10), bg="#9DC88D")
trackerLabel.grid(row=1,column=0,columnspan=3)


# food tracker specific functions

def add_item():
    global foodbought
    global foodLabel
    global counter3
    global trackerLabel
    global massBought
    global gramsWasted

    fooditem = foodEntry.get()
    mass = numEntry.get()

    foodEntry.delete(0, END)
    numEntry.delete(0, END)

    if mass != '':
        mass = int(mass)

        if len(foodLabel) == 0:
            counter3 = 0

        if fooditem in foodbought:
            foodbought = foodbought

        elif counter3 < 16:
            foodbought.append(fooditem)
            massBought.append(mass)
            gramsWasted.append(0)

            foodLabel.append(
                tk.Label(foodFrame, text=f"{fooditem} - {mass} grams", fg="black", bg="#9DC88D", font=("Arial", 10),anchor="w", justify=CENTER))

            foodLabel[counter3].grid(sticky=W, column=0,row=counter3 + 1, padx=15)
            counter3 += 1
            trackerLabel.configure(text=f"This is the food tracker frame\n you currently have {counter3} items tracked")
        
        else:
            trackerLabel.configure(
                text=f"This is the food tracker frame\n you currently have {len(foodbought)} items tracked, this is the maximum.")


def remove():
    global foodbought
    global foodLabel
    global trackerLabel
    global trackerLabel
    global counter3
    global massBought

    itemToRemove = foodRmv.get()
    length = len(foodbought)
    
    foodRmv.delete(0, END)

    if length > 0:
        for i in range(length):

            if itemToRemove == foodbought[i]:
                # index = foodbought.index(foodbought[i])

                counter3 -= 1
                foodLabel[i].destroy()
                massBought.remove(massBought[i])
                foodLabel.remove(foodLabel[i])
                foodbought.remove(itemToRemove)
                length = len(foodbought)

                trackerLabel.configure(
                    text=f"This is the food tracker frame\n you currently have {length} items tracked.")


#BUTTONS AND ENTRY BARS
#NAVIGATION
mainBtn = tk.Button(trackerFrame, text="MAIN MENU", command=to_main, font=("Arial", 10), bg="#F1B24A")
mainBtn.grid(column=0, row=0)

wasteFrameBtn = tk.Button(trackerFrame, text="WASTE TRACKER", command=to_waste, font=("Arial", 10), bg="#F1B24A")
wasteFrameBtn.grid(column=1, row=0)

habitBtn = tk.Button(trackerFrame, text="HABIT TRACKER", command=to_habits, bg="#F1B24A", fg="#031B13",font=("Arial", 10))
habitBtn.grid(column=2, row = 0)

#GENERAL PURPOSE
foodEntryBtn = tk.Button(enterFrame, text="ENTER", command=add_item, font=("Arial", 10), bg="#F1B24A")
foodEntryBtn.grid(row=0, column=3)

foodEntLbl = tk.Label(enterFrame, text="Enter the name and\n mass of the food you purchased:", font=("Arial", 10),bg="#9DC88D")
foodEntLbl.grid(row=0, column=0, padx = 3, pady=2)

foodEntry = tk.Entry(enterFrame, width=18, font=("Arial", 10))
foodEntry.grid(row=0, column=1)

numEntry = tk.Entry(enterFrame, width=3, font=("Arial", 10))
numEntry.grid(row=0, column=2)

foodRmvLbl = tk.Label(enterFrame, text="Enter the name of the item\nyou'd like to remove", font=("Arial", 10),bg="#9DC88D")
foodRmvLbl.grid(row=1, column=0)

foodRmv = tk.Entry(enterFrame, width=18, font=("Arial", 10))
foodRmv.grid(row=1, column=1)

foodRmvBtn = tk.Button(enterFrame, text="ENTER", command=remove, font=("Arial", 10), bg="#F1B24A")
foodRmvBtn.grid(row=1, column=3)

# WASTE TRACKER AND ALL ITS COMPONENTS

#frames and general set up
wasteFrame = tk.Frame(win, width=600, height=550, bg="#164A41", padx=15, pady=15)

wasteLbl = tk.Label(wasteFrame, text="This is the food waste tracker!\n you've currently wasted 0 grams of food! :)",font=("Arial", 10), bg="#9DC88D")
wasteLbl.grid(column=0, row=1, columnspan=3)

foodWasteFrame = tk.Frame(wasteFrame, width=550, height=340, bg="white", padx=10, pady=10)
foodWasteFrame.grid_propagate(0)
foodWasteFrame.grid(row=2, column=0, columnspan=3, pady=5)

wasteEnterFrame = tk.Frame(wasteFrame, width=550, height=100, bg="white", padx=5, pady=10)
wasteEnterFrame.grid_propagate(0)
wasteEnterFrame.grid(row=3, column=0, columnspan=3, pady=10)


# waste tracker specific functions

# calculate waste
def wasteCalc():
    global wasteLabel
    global counter5
    global foodbought
    global trackerLabel
    global totalWaste
    global wasteLbl

    fooditem = wasteEntry.get()
    massUsed = int(numEntry2.get())

    wasteEntry.delete(0, END)
    numEntry2.delete(0, END)

    if len(foodLabel) == 0:
        counter5 = 0

    if fooditem in foodbought:

        index = foodbought.index(fooditem)

        gramsWasted[index] = massBought[index] - massUsed
        totalWaste += gramsWasted[index]

        wasteLabel.append(
            tk.Label(foodWasteFrame, text=f"You wasted {gramsWasted[index]} grams of {fooditem}", fg="black",
                     bg="#9DC88D", font=("Arial", 10), anchor="w", justify=CENTER))

        wasteLabel[counter5].grid(sticky=W, column=0, row=counter5 + 1, padx=15)
        counter5 += 1

        wasteLbl.configure(text=f"This is the food waste frame\n you've currently wasted {totalWaste} grams of food.")


# BUTTONS AND ENTRY BARS

# navigation
mainWasteBtn = tk.Button(wasteFrame, text="MAIN MENU", command=to_main, bg="#fff6e9", fg="#031B13", font=("Arial", 10))
mainWasteBtn.grid(column=0, row=0)

trackerBtn = tk.Button(wasteFrame, text="FOOD TRACKER", command=to_tracker, bg="#F1B24A", fg="#031B13",font=("Arial", 10))
trackerBtn.grid(column=1, row=0)

habitBtn = tk.Button(wasteFrame, text="HABIT TRACKER", command=to_habits, bg="#F1B24A", fg="#031B13",font=("Arial", 10))
habitBtn.grid(column=2, row = 0)

# general purpose
wasteEntLbl = tk.Label(wasteEnterFrame, text="Enter the name of the food\nand the mass you used!", font=("Arial", 10),bg="#9DC88D")
wasteEntLbl.grid(row=0, column=0)

wasteEntry = tk.Entry(wasteEnterFrame, width=18, font=("Arial", 10))
wasteEntry.grid(row=0, column=1)

numEntry2 = tk.Entry(wasteEnterFrame, width=5, font=("Arial", 10))
numEntry2.grid(row=0, column=2)

wasteCalcBtn = tk.Button(wasteEnterFrame, text="ENTER", command=wasteCalc, font=("Arial", 10), bg="#F1B24A")
wasteCalcBtn.grid(row=0, column=3)

# HABIT LOGGER AND ITS COMPONENTS

habitFrame = tk.Frame(win, width=600, height=550, bg="#164A41", padx=15, pady=15)

habitLbl = tk.Label(habitFrame, text="This is the general habit logger!\nyou can log your habits below!",font=("Arial", 10), bg="#9DC88D")
habitLbl.grid(column=0, row=1, columnspan=3)

habitLogFrame = tk.Frame(habitFrame, width=550, height=300,bg="white", padx=10, pady=10)
habitLogFrame.grid_propagate(0)
habitLogFrame.grid(row=2, column=0, columnspan=3, pady=5)

habitEnterFrame = tk.Frame(habitFrame, width=550, height=140,bg="white", padx=5, pady=10)
habitEnterFrame.grid_propagate(0)
habitEnterFrame.grid(row=3, column=0, columnspan=3, pady=10)


# habit logger specific functions

def add_habit():
    global counter6
    global habits
    global habitLabel
    global habitTimes

    habit = habitEntry.get()

    habitEntry.delete(0, END)


    if len(habitLabel) == 0:
        counter6 = 0

    if habit in habits:
        habitLabel = habitLabel

    elif counter6 < 16:
        habits.append(habit)
        habitTimes.append(0)

        habitLabel.append(tk.Label(habitLogFrame, text=f"You have done this habit: {habit} - 0 times.", fg="black", bg="#9DC88D", font=("Arial", 10),anchor="w", justify=CENTER))


        habitLabel[counter6].grid(sticky=W, column=0, row=counter6 + 1, padx=15)
        counter6 += 1


def log_habit():
    global habits
    global habitLabel
    global habitTimes

    habitToCount = habitCntEntry.get()
    for i in range(len(habits)):
        if habitToCount == habits[i]:
            habitTimes[i] +=1
            habitLabel[i].configure(text = f"You have done this habit: {habits[i]} - {habitTimes[i]} times.")


def remove_habit():
    global habits
    global habitLabel
    global habitTimes
    global counter6

    habitToRemove = habitRmv.get()
    length = len(habits)
    habitRmv.delete(0, END)

    if length > 0:
        for i in range(length):
            if habitToRemove == habits[i]:
                # index = foodbought.index(foodbought[i])

                counter6 -= 1
                habitLabel[i].destroy()
                habitLabel.remove(habitLabel[i])
                habits.remove(habitToRemove)


#BUTTONS AND ENTRY BARS
#navigation
mainFrmBtn = tk.Button(habitFrame, text="MAIN MENU", command=to_main, font=("Arial", 10), bg="#F1B24A")
mainFrmBtn.grid(column=0, row=0)

wasteFrmBtn = tk.Button(habitFrame, text="WASTE TRACKER", command=to_waste, font=("Arial", 10), bg="#F1B24A")
wasteFrmBtn.grid(column=1, row=0)

trackerFrmBtn = tk.Button(habitFrame,text = "FOOD TRACKER", command=to_tracker, font = ("Arial",10), bg ="#F1B24A")
trackerFrmBtn.grid(column = 2, row = 0)

#functions
habitEntryBtn = tk.Button(habitEnterFrame, text="ENTER", command=add_habit, font=("Arial", 10), bg="#F1B24A")
habitEntryBtn.grid(row=0, column=3)

habitEntLbl = tk.Label(habitEnterFrame, text="Enter your new habit!:", font=("Arial", 10), bg="#9DC88D")
habitEntLbl.grid(row=0, column=0)

habitEntry = tk.Entry(habitEnterFrame, width=20, font=("Arial", 10))
habitEntry.grid(row=0, column=1)


habitCounterBtn = tk.Button(habitEnterFrame, text="LOG", command=log_habit, font=("Arial", 10), bg="#F1B24A")
habitCounterBtn.grid(row=1, column=3)

habitCounterLbl = tk.Label(habitEnterFrame, text="Enter the habit you did \nand press the button to log it!:", font=("Arial", 10), bg="#9DC88D")
habitCounterLbl.grid(row=1, column=0, padx = 3, pady = 5)

habitCntEntry = tk.Entry(habitEnterFrame, width=20, font=("Arial", 10))
habitCntEntry.grid(row=1, column=1)


habitRmvLbl = tk.Label(habitEnterFrame, text="Enter the name of the item\nyou'd like to remove", font=("Arial", 10),bg="#9DC88D")
habitRmvLbl.grid(row=2, column=0)

habitRmv = tk.Entry(habitEnterFrame, width=20, font=("Arial", 10))
habitRmv.grid(row=2, column=1)

habitRmvBtn = tk.Button(habitEnterFrame, text="ENTER", command=remove_habit, font=("Arial", 10), bg="#F1B24A")
habitRmvBtn.grid(row=2, column=3)

tk.mainloop()